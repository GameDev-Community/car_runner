﻿#if false // все ебать их в жопу шейдеры для кружков сидят в ахуе - ждут, пока скрин спейс в юнити работать начнёт.
using Externals.Utils.Shaders;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Testing.Shaders
{
    public class CircleWipeFeature : ScriptableRendererFeature
    {
        private class CustomRenderPass : SimpleRenderPass
        {
            public CustomRenderPass(Material mat) : base(mat)
            {
            }


            public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
            {
                ExecutePasses(1, ref context);
            }
        }


        [SerializeField] private Material _mat;
        [SerializeField] private RenderPassEvent _renderPassEvent = RenderPassEvent.AfterRenderingTransparents;

        private CustomRenderPass _renderPass;


        public override void Create()
        {
            _renderPass = new(_mat)
            {
                renderPassEvent = _renderPassEvent
            };
        }


        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            renderer.EnqueuePass(_renderPass);
        }
    }
}
#endif